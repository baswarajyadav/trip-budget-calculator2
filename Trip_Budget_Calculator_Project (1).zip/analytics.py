class AnalyticsService:
    def __init__(self, repository):
        self.repository = repository

    def summary(self, trip_id):
        trip = self.repository.get_trip(trip_id)
        if not trip:
            raise ValueError("Trip not found.")
        categories = self.repository.category_totals(trip_id)
        lines = [f"Analytics for {trip['name']}"]
        if not categories:
            lines.append("No expenses recorded yet.")
        else:
            lines.append("Category-wise spending:")
            for item in categories:
                lines.append(f"  {item['category']}: ₹{item['total']:.2f}")
            lines.append(f"Highest spending category: {categories[0]['category']}")
        lines.append(f"Average planned budget per person: ₹{trip['budget']/trip['people']:.2f}")
        return "\n".join(lines)

    def predict_budget(self, destination):
        """Simple transparent estimate: mean of previous trip spend for same destination."""
        trips = [t for t in self.repository.get_all_trips()
                 if t["destination"].strip().lower() == destination.strip().lower()
                 and t["spent"] > 0]
        if not trips:
            return None
        return sum(t["spent"] for t in trips) / len(trips)
