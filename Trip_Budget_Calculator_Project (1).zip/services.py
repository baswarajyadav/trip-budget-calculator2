from models import Trip, Expense

class TripService:
    def __init__(self, repository):
        self.repository = repository

    def create_trip(self, name, destination, start_date, people, budget):
        if not name.strip() or not destination.strip():
            raise ValueError("Trip name and destination are required.")
        if people < 1 or budget < 0:
            raise ValueError("People must be positive and budget cannot be negative.")
        return self.repository.add_trip(Trip(name, destination, start_date, people, budget))

    def add_expense(self, trip_id, category, description, amount):
        allowed = {"transport", "stay", "food", "activities", "other"}
        if category not in allowed:
            raise ValueError("Use transport, stay, food, activities, or other.")
        if not description.strip() or amount < 0:
            raise ValueError("Description is required and amount cannot be negative.")
        self.repository.add_expense(Expense(trip_id, category, description, amount))

    def budget_status(self, trip_id):
        trip = self.repository.get_trip(trip_id)
        if not trip:
            raise ValueError("Trip not found.")
        spent, budget = trip["spent"], trip["budget"]
        if budget == 0:
            return f"Budget: ₹0 | Spent: ₹{spent:.2f} | No budget was set."
        ratio = spent / budget
        if ratio >= 1:
            label = "ALERT: Budget exceeded."
        elif ratio >= 0.8:
            label = "WARNING: 80% or more of the budget is used."
        else:
            label = "SAFE: Spending is within the planned range."
        return f"{label} Used: {ratio * 100:.1f}% | Remaining: ₹{budget-spent:.2f}"

