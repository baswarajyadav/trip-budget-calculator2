from dataclasses import dataclass
from datetime import date

@dataclass
class Trip:
    name: str
    destination: str
    start_date: str
    people: int
    budget: float

@dataclass
class Expense:
    trip_id: int
    category: str
    description: str
    amount: float
