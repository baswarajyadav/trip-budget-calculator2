from datetime import date

def read_text(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("This field cannot be blank.")

def read_money(prompt):
    while True:
        try:
            value = float(input(prompt).strip())
            if value < 0:
                raise ValueError
            return round(value, 2)
        except ValueError:
            print("Enter a valid amount greater than or equal to zero.")

def read_int(prompt, minimum=0):
    while True:
        try:
            value = int(input(prompt).strip())
            if value < minimum:
                raise ValueError
            return value
        except ValueError:
            print(f"Enter a whole number greater than or equal to {minimum}.")

def read_date(prompt):
    while True:
        value = input(prompt).strip()
        try:
            date.fromisoformat(value)
            return value
        except ValueError:
            print("Enter a valid date in YYYY-MM-DD format.")
