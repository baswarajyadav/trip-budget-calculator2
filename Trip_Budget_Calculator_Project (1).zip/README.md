# Trip Budget Calculator

A beginner-friendly Python terminal application for planning trips, recording expenses,
monitoring budgets, analyzing spending, estimating costs from previous trips, splitting
costs per person, and exporting reports.

## Requirements
- Python 3.10 or newer
- No third-party packages required (uses Python standard library)

## Run
1. Extract the ZIP file.
2. Open the extracted folder in VS Code or a terminal.
3. Run: `python main.py`

The SQLite database is created automatically at `data/trips.db`.

## Run tests
Run: `python -m unittest discover -s tests -v`

## Architecture
- `main.py`: menu and user interaction
- `models.py`: dataclasses for Trip and Expense
- `validators.py`: defensive input validation
- `services.py`: application rules and budget alerts
- `analytics.py`: category analysis and historical average prediction
- `storage.py`: SQLite repository and persistence
- `exporters.py`: CSV and Markdown report generation

## Design patterns
- Repository Pattern: database operations are isolated in `TripRepository`.
- Service Layer: `TripService` contains application rules.
- Strategy-ready calculation design: prediction is isolated in `AnalyticsService` and can be extended
  with additional estimation strategies.

## Innovation features
- Historical-average trip cost estimate by destination (requires previous records)
- Category-wise spending analysis
- 80% and 100% budget threshold warnings
- Per-person cost split
- CSV and Markdown report exports

## Notes
The prediction is a simple historical average, not a machine-learning model. Its accuracy depends
on the number and quality of previously recorded trips. The app is local and does not include
accounts, cloud sync, or online booking.
