from services import TripService
from analytics import AnalyticsService
from exporters import export_csv, export_markdown
from storage import TripRepository
from validators import read_text, read_money, read_int, read_date

def show_menu():
    print("""
========== TRIP BUDGET CALCULATOR ==========
1. Add a trip
2. View all trips
3. Add expense to a trip
4. View trip details
5. Budget analytics and alerts
6. Predict budget from past trips
7. Split trip cost among people
8. Search trips
9. Export reports
0. Exit
""")

def main():
    repo = TripRepository()
    service = TripService(repo)
    analytics = AnalyticsService(repo)

    while True:
        show_menu()
        choice = input("Choose an option: ").strip()

        try:
            if choice == "1":
                name = read_text("Trip name: ")
                destination = read_text("Destination: ")
                start = read_date("Start date (YYYY-MM-DD): ")
                people = read_int("Number of people: ", minimum=1)
                budget = read_money("Total planned budget (₹): ")
                trip_id = service.create_trip(name, destination, start, people, budget)
                print(f"Trip created successfully. Trip ID: {trip_id}")

            elif choice == "2":
                trips = repo.get_all_trips()
                if not trips:
                    print("No trips found.")
                for trip in trips:
                    print(f"#{trip['id']} | {trip['name']} | {trip['destination']} | "
                          f"Budget ₹{trip['budget']:.2f} | Spent ₹{trip['spent']:.2f}")

            elif choice == "3":
                trip_id = read_int("Trip ID: ", minimum=1)
                category = read_text("Category (transport/stay/food/activities/other): ").lower()
                description = read_text("Expense description: ")
                amount = read_money("Expense amount (₹): ")
                service.add_expense(trip_id, category, description, amount)
                print("Expense saved.")
                print(service.budget_status(trip_id))

            elif choice == "4":
                trip_id = read_int("Trip ID: ", minimum=1)
                trip = repo.get_trip(trip_id)
                if not trip:
                    print("Trip not found.")
                else:
                    print(f"\n{trip['name']} — {trip['destination']}")
                    print(f"Date: {trip['start_date']} | People: {trip['people']}")
                    print(f"Budget: ₹{trip['budget']:.2f} | Spent: ₹{trip['spent']:.2f}")
                    print(f"Remaining: ₹{trip['budget'] - trip['spent']:.2f}")
                    for item in repo.get_expenses(trip_id):
                        print(f"  {item['category']}: {item['description']} — ₹{item['amount']:.2f}")

            elif choice == "5":
                trip_id = read_int("Trip ID: ", minimum=1)
                print(analytics.summary(trip_id))
                print(service.budget_status(trip_id))

            elif choice == "6":
                destination = read_text("Destination/category label to estimate for (e.g. Goa): ")
                prediction = analytics.predict_budget(destination)
                if prediction is None:
                    print("Not enough past data yet. Add completed trips and expenses first.")
                else:
                    print(f"Estimated cost based on past records: ₹{prediction:.2f}")

            elif choice == "7":
                trip_id = read_int("Trip ID: ", minimum=1)
                people = read_int("Number of people sharing: ", minimum=1)
                trip = repo.get_trip(trip_id)
                if not trip:
                    print("Trip not found.")
                else:
                    print(f"Spent per person: ₹{trip['spent'] / people:.2f}")

            elif choice == "8":
                keyword = read_text("Search name/destination: ").lower()
                results = [t for t in repo.get_all_trips()
                           if keyword in t['name'].lower() or keyword in t['destination'].lower()]
                for t in results:
                    print(f"#{t['id']} {t['name']} — {t['destination']}")

            elif choice == "9":
                trips = repo.get_all_trips()
                export_csv(trips, repo)
                export_markdown(trips, repo)
                print("Reports exported to the reports/ folder.")

            elif choice == "0":
                print("Thank you for using Trip Budget Calculator.")
                break
            else:
                print("Invalid choice. Select 0–9.")
        except (ValueError, KeyError) as exc:
            print(f"Could not complete operation: {exc}")
        except Exception as exc:
            print(f"Unexpected error: {exc}")

if __name__ == "__main__":
    main()
