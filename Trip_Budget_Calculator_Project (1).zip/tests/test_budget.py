import tempfile
import unittest
from pathlib import Path
from storage import TripRepository
from services import TripService

class BudgetTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.repo = TripRepository(Path(self.temp.name) / "test.db")
        self.service = TripService(self.repo)
        self.trip_id = self.service.create_trip("Test Trip", "Goa", "2026-12-01", 2, 1000)

    def tearDown(self):
        self.temp.cleanup()

    def test_expense_updates_total(self):
        self.service.add_expense(self.trip_id, "food", "Lunch", 250)
        self.assertEqual(self.repo.get_trip(self.trip_id)["spent"], 250)

    def test_negative_expense_rejected(self):
        with self.assertRaises(ValueError):
            self.service.add_expense(self.trip_id, "food", "Lunch", -5)

    def test_invalid_category_rejected(self):
        with self.assertRaises(ValueError):
            self.service.add_expense(self.trip_id, "invalid", "Item", 10)

if __name__ == "__main__":
    unittest.main()
