import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).parent / "data" / "trips.db"

class TripRepository:
    """Repository Pattern: isolates SQL operations from application logic."""
    def __init__(self, db_path=DB_PATH):
        self.db_path = str(db_path)
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def _connect(self):
        connection = sqlite3.connect(self.db_path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        return connection

    def _initialize(self):
        with self._connect() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS trips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                destination TEXT NOT NULL,
                start_date TEXT NOT NULL,
                people INTEGER NOT NULL CHECK(people > 0),
                budget REAL NOT NULL CHECK(budget >= 0)
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS expenses (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_id INTEGER NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                amount REAL NOT NULL CHECK(amount >= 0),
                created_at TEXT DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(trip_id) REFERENCES trips(id) ON DELETE CASCADE
            )""")

    def add_trip(self, trip):
        with self._connect() as con:
            cur = con.execute(
                "INSERT INTO trips(name,destination,start_date,people,budget) VALUES(?,?,?,?,?)",
                (trip.name, trip.destination, trip.start_date, trip.people, trip.budget))
            return cur.lastrowid

    def add_expense(self, expense):
        with self._connect() as con:
            exists = con.execute("SELECT id FROM trips WHERE id=?", (expense.trip_id,)).fetchone()
            if not exists:
                raise ValueError("Trip ID does not exist.")
            con.execute(
                "INSERT INTO expenses(trip_id,category,description,amount) VALUES(?,?,?,?)",
                (expense.trip_id, expense.category, expense.description, expense.amount))

    def get_trip(self, trip_id):
        with self._connect() as con:
            row = con.execute("""
                SELECT t.*, COALESCE(SUM(e.amount),0) AS spent
                FROM trips t LEFT JOIN expenses e ON t.id=e.trip_id
                WHERE t.id=? GROUP BY t.id
            """, (trip_id,)).fetchone()
            return dict(row) if row else None

    def get_all_trips(self):
        with self._connect() as con:
            rows = con.execute("""
                SELECT t.*, COALESCE(SUM(e.amount),0) AS spent
                FROM trips t LEFT JOIN expenses e ON t.id=e.trip_id
                GROUP BY t.id ORDER BY t.id DESC
            """).fetchall()
            return [dict(row) for row in rows]

    def get_expenses(self, trip_id):
        with self._connect() as con:
            rows = con.execute(
                "SELECT * FROM expenses WHERE trip_id=? ORDER BY id", (trip_id,)).fetchall()
            return [dict(row) for row in rows]

    def category_totals(self, trip_id):
        with self._connect() as con:
            rows = con.execute("""
                SELECT category, SUM(amount) AS total FROM expenses
                WHERE trip_id=? GROUP BY category ORDER BY total DESC
            """, (trip_id,)).fetchall()
            return [dict(row) for row in rows]
