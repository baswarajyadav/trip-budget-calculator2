import csv
from pathlib import Path

REPORTS = Path(__file__).parent / "reports"

def export_csv(trips, repository):
    REPORTS.mkdir(exist_ok=True)
    path = REPORTS / "trip_summary.csv"
    with path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["Trip ID", "Name", "Destination", "Date", "People",
                         "Budget (INR)", "Spent (INR)", "Remaining (INR)"])
        for t in trips:
            writer.writerow([t["id"], t["name"], t["destination"], t["start_date"],
                             t["people"], t["budget"], t["spent"], t["budget"]-t["spent"]])
    return path

def export_markdown(trips, repository):
    REPORTS.mkdir(exist_ok=True)
    path = REPORTS / "trip_summary.md"
    lines = ["# Trip Budget Summary", "",
             "| Trip | Destination | Budget | Spent | Remaining |",
             "|---|---|---:|---:|---:|"]
    for t in trips:
        lines.append(f"| {t['name']} | {t['destination']} | ₹{t['budget']:.2f} | "
                     f"₹{t['spent']:.2f} | ₹{t['budget']-t['spent']:.2f} |")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path
